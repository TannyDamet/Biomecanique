clear all; close all;


data1 = open("sagital_1.csv");
data2 = open("sagital_2.csv");
data3 = open("sagital_3.csv");
data4 = open("sagital_4.csv");

p = 1;
q= 1000;
o = 200;

%PacketCounter	SampleTimeFine	Euler_X	Euler_Y	Euler_Z	FreeAcc_X	FreeAcc_Y	FreeAcc_Z	Status
euler_1_x = data1.data(p:q,3);
euler_2_x = data2.data(p:q,3);
euler_3_x = data3.data(p:q,3);
euler_4_x = data4.data(p:q,3);

angle_euler_1_x = Mean(euler_1_x',o,q)
angle_euler_2_x = Mean(euler_2_x',o,q)
angle_euler_3_x = Mean(euler_3_x',o,q)
angle_euler_4_x = Mean(euler_4_x',o,q)

euler_1_y = data1.data(p:q,4);
euler_2_y = data2.data(p:q,4);
euler_3_y = data3.data(p:q,4);
euler_4_y = data4.data(p:q,4);

angle_euler_1_y = Mean(euler_1_y',o,q)
angle_euler_2_y = Mean(euler_2_y',o,q)
angle_euler_3_y = Mean(euler_3_y',o,q)
angle_euler_4_y = Mean(euler_4_y',o,q)

euler_1_z = data1.data(p:q,5);
euler_2_z = data2.data(p:q,5);
euler_3_z = data3.data(p:q,5);
euler_4_z = data4.data(p:q,5)

angle_euler_1_z = Mean(euler_1_z',o,q)
angle_euler_2_z = Mean(euler_2_z',o,q)
angle_euler_3_z = Mean(euler_3_z',o,q)
angle_euler_4_z = Mean(euler_4_z',o,q)

angle_euler_1_x = deg2rad(angle_euler_1_x);
angle_euler_1_y = deg2rad(angle_euler_1_y);
angle_euler_1_z = deg2rad(angle_euler_1_z);

angle_euler_2_x = deg2rad(angle_euler_2_x);
angle_euler_2_y = deg2rad(angle_euler_2_y);
angle_euler_2_z = deg2rad(angle_euler_2_z);

angle_euler_3_x = deg2rad(angle_euler_3_x);
angle_euler_3_y = deg2rad(angle_euler_3_y);
angle_euler_3_z = deg2rad(angle_euler_3_z);

angle_euler_4_x = deg2rad(angle_euler_4_x);
angle_euler_4_y = deg2rad(angle_euler_4_y);
angle_euler_4_z = deg2rad(angle_euler_4_z);

angle_1 = [0 0 0];

Rz = [cos(angle_1(1)) sin(angle_1(1)) 0 ; -sin(angle_1(1)) cos(angle_1(1)) 0; 0 0 1];
Ry = [cos(angle_1(2)) 0 -sin(angle_1(2)) ; 0 1 0; sin(angle_1(2)) 0 cos(angle_1(2))];
Rx = [1 0 0 ; 0 cos(angle_1(3)) -sin(angle_1(3)); 0 sin(angle_1(3)) cos(angle_1(3))];

rot_mat = Rx*Ry*Rz;

[RM1,RM_1] = RotMat(angle_euler_1_x,angle_euler_1_y,angle_euler_1_z,rot_mat);

[RM2,RM_2]= RotMat(angle_euler_2_x,angle_euler_2_y,angle_euler_2_z,rot_mat);

[RM3,RM_3]= RotMat(angle_euler_3_x,angle_euler_3_y,angle_euler_3_z,rot_mat);

[RM4,RM_4]= RotMat(angle_euler_4_x,angle_euler_4_y,angle_euler_4_z,rot_mat);


%rot_mat_2 =RotMat(angle_euler_2_x,angle_euler_2_y,angle_euler_2_z,rot_mat);


bras = 0.29;
avant_bras = 0.25;
angle_imu1 = [0 0 0];

angle_epaule_1_rad_x = RM_2(:,1);
angle_epaule_1_rad_y = RM_2(:,2);
angle_epaule_1_rad_z = RM_2(:,3);

angle_coude_1_rad_x =  RM_1(:,1);
angle_coude_1_rad_y = RM_1(:,2);
angle_coude_1_rad_z = RM_1(:,3);

angle_epaule_2_rad_x =  RM_3(:,1);
angle_epaule_2_rad_y = RM_3(:,2);
angle_epaule_2_rad_z = RM_3(:,3);

angle_coude_2_rad_x =  RM_4(:,1);
angle_coude_2_rad_y = RM_4(:,2);
angle_coude_2_rad_z = RM_4(:,3);

coude_1 = [];
poignet_1 = [];
coude_2 = [];
poignet_2 = [];
c1Tw = [bras 0 0];
p1Tw = [avant_bras 0 0];
c2Tw = [bras 0 0];
p2Tw = [avant_bras 0 0];


for i =1:length(angle_epaule_1_rad_x)
    c1Rw = rotz(angle_coude_1_rad_z(i))*roty(angle_coude_1_rad_y(i))*rotx(angle_coude_1_rad_x(i));
    %changement de repere du monde au coude 
    c1Mw = [c1Rw c1Tw';0 0 0 1];
    Pc1 = inv(c1Mw)*[0 0 0 1]';
    coude_1=[coude_1 Pc1]
    p1Rw = rotz(angle_coude_1_rad_x(i))*roty(angle_coude_1_rad_y(i))*rotx(angle_coude_1_rad_x(i))
    p1Mw = [p1Rw p1Tw';0 0 0 1];
    Pp1 = inv(p1Mw)*[0 0 0 1]' + Pc1;
    poignet_1=[poignet_1 Pp1] 

%     c2Rw = rotz(angle_coude_2_rad_z(i))*roty(angle_coude_2_rad_y(i))*rotx(angle_coude_2_rad_x(i));
%     %changement de repere du monde au coude 
%     c2Mw = [c2Rw c2Tw';0 0 0 1];
%     Pc2 = inv(c2Mw)*[0 0 0 1]';
%     coude_2=[coude_2 Pc2]
% 
%     p2Rw = rotz(angle_coude_2_rad_x(i))*roty(angle_coude_2_rad_y(i))*rotx(angle_coude_2_rad_x(i))
%     p2Mw = [p2Rw p2Tw';0 0 0 1];
%     Pp2 = inv(p2Mw)*[0 0 0 1]' + Pc2;
%     poignet_2=[poignet_2 Pp2] 

end


% juste pour l'affichage
%figure(1);
title("bras dans le plan sagittal");
axis equal
mRw = rotz(-pi/2);
mTw = [0 0 0];
mMw = [mRw mTw';0 0 0 1];
Po = [0 0 0 0]'
for i=1:length(angle_coude_1_rad_x)
    Pc1w=coude_1(:,i);
    Pc1m = mMw*Pc1w;
    Pp1w=poignet_1(:,i);
    Pp1m = mMw*Pp1w;
    segment1 = [Po(1:4) Pc1m(1:4) Pp1m(1:4)]
    segment1(2,1:3)

%     Pc2w=coude_2(:,i);
%     Pc2m = mMw*Pc2w;
%     Pp2w=poignet_2(:,i);
%     Pp2m = mMw*Pp2w;
%     segment2 = [Po(1:4) Pc2m(1:4) Pp2m(1:4)]
%     segment2(2,1:3)
    
    figure(i)
    plot3(segment1(1,1:3),segment1(2,1:3),segment1(3,1:3),"o-")   
    hold on;
%     plot3(segment2(1,1:3),segment2(2,1:3),segment2(3,1:3),"o-") 
%     hold on;
end


xlabel("Axe des x"); ylabel("Axe des y"); zlabel("Axe des z");

% on a P0 Pc(i) Pp(i)

C10 = Pc1m-Po;
PC1 = Pp1m-Pc1m;

alpha1 = acos((PC1'*C10)/(norm(PC1')*norm(C10)));

angleB_AB1 = conversion_rad_cos(alpha1)

C20 = Pc2m-Po;
PC2 = Pp2m-Pc2m;

alpha2 = acos((PC2'*C10)/(norm(PC2')*norm(C20)));

angleB_AB2 = conversion_rad_cos(alpha2)

function alphaR = conversion_deg_rad(alpha)
    alphaR = alpha *(pi/180);
end

function alphaD = conversion_rad_cos(alpha)
    alphaD = alpha /(pi/180);
end

function Rz = rotz(alpha)
% create rotation matrix around z axis with alpha in radian
  Rz = [cos(alpha) sin(alpha) 0; -sin(alpha) cos(alpha) 0; 0 0 1];
end

function Ry = roty(teta)
% create rotation matrix around y axis with alpha in radian
  Ry = [cos(teta) 0 -sin(teta); 0 1 0; sin(teta) 0 cos(teta)];
end

function Rx = rotx(gamma)
% create rotation matrix around x axis with alpha in radian
  Rx = [1 0 0; 0 cos(gamma) sin(gamma); 0 -sin(gamma) cos(gamma)];
end

function [RM,RM_1] = RotMat(angle_euler_x,angle_euler_y,angle_euler_z,rot_mat)
    C1 = 1;

    N = length(angle_euler_x);
    for k = 1:N
        a = angle_euler_x(k);
        b = angle_euler_y(k);
        c = angle_euler_z(k);
    
        Rz = [cos(a) sin(a) 0 ; -sin(a) cos(a) 0; 0 0 1];
        Ry = [cos(b) 0 -sin(b) ; 0 1 0; sin(b) 0 cos(b)];
        Rx = [1 0 0 ; 0 cos(c) -sin(c); 0 sin(c) cos(c)];

        rot_mat_i(:,:,k) = Rx*Ry*Rz;

    
        if k == 1
        C1 = C1 * inv(rot_mat)*rot_mat_i(:,:,k);
        end
    
    
        if k > 1
        C1 = C1 * inv(rot_mat_i(:,:,k-1))*rot_mat_i(:,:,k);
        end
    
        RM = C1;

        RM_1(k,:) = rotm2eul(RM)

        
    end
end

function Moyenne = Mean(Vec, l, N)

x = 200;
Moyenne = [];
for i = 1:l:N
    m = mean(Vec(i:x));
    Moyenne = [Moyenne m]
    x = x+200;
end
end